/*
Darstellung einer Wort-Uhr auf der Hardware des Retro-PONG-Spiels 

Version vom 4.11.2011


Realisiert mit ATmega8 an 4.096MHz Quarz

Keine Bedienelemente - die Uhr empf�ngt DCF-77 Signale und stellt sich selbst.


Angezeigt wird eine interne Uhr, die vom DCF-Empfang bei korrektem Empfang min�tlich gestellt wird.
Die Flanke jedes Sekundensignals wird zur Feinjustierung der hunderstel Sekunden benutzt.
Ohne Empfang l�uft die interne Uhr mit der Zeit weg (Quarz zu ungenau). Das k�nnen schon mal 2 Minuten pro Tag sein.

Der DCF-77 Empf�nger startet erst nach einer fallenden Flanke an seinem PON Eingang.


Da der Compiler/Optimizer leider ignoriert, dass eine Variable als volatile gekennzeichnet ist
und dann den Wert bei einem Vergleich nicht neu aus dem Speicher liest, benutze ich zur �bergabe eines Bits aus einer 
Interrupt-Routine einen Portpin. Der ist definitiv volatile - und das ber�cksichtigt der Compiler bisher immer.
Man kann daher an PD3 den 200Hz Takt abgreifen.

--- Anschluss Quarz ---
B6 und B7: 4096KHz Quarz    (Prozessorpin 7+8) 

--- Anschluss DCF-77-Empf�nger ---
K1: GND
K2: +5V                   (PD2)
C4: output PowerOn DCF77  (PC4)
C5: input DCF77-Empf�nger (PC5)
*/
#define F_CPU 4096000UL	/* CPU clock in Hertz */

#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>


//Potenzen von 2
#define BIT0 1
#define BIT1 2
#define BIT2 4
#define BIT3 8
#define BIT4 16
#define BIT5 32
#define BIT6 64
#define BIT7 128
#define BIT8 256
#define BIT9 512
#define BIT10 1024
#define BIT11 2048

//Standard Datentypen
#define U8  unsigned char
#define U16 unsigned int
#define U32 unsigned long
#define I16 int

//I/O Makros DCF77-Empf�nger
#define   DI_DCF77_BIT (PINC & BIT5)
#define   DO_DCF_ENABLE (PORTC &=~ BIT4)
#define   DO_DCF_DISABLE (PORTC |= BIT4)
#define   DO_DCF_POWERSUPPLY (PORTD |= BIT2)

//I/O Makros Spaltentreiber (Shift&Store Schieberegister CD4094)
#define		DO_DATA_H		(PORTB |=  BIT4)
#define		DO_DATA_L		(PORTB &= ~BIT4)
#define		DO_CLK_H	  (PORTB |=  BIT3)
#define		DO_CLK_L	  (PORTB &= ~BIT3)
#define		DO_STROBE_H	(PORTB |=  BIT2)
#define		DO_STROBE_L	(PORTB &= ~BIT2)



/* DCF-77 Decoder */
/*
W�hrend jeder Minute werden die Nummern von Minute, Stunde, Tag, Wochentag, 
Monat und Jahr BCD-kodiert durch Impulsmodulation der Sekundenmarken �bertragen. 
Dieses "Telegramm" gilt jeweils f�r die folgende Minute. 
Dabei entsprechen Sekundenmarken mit einer Dauer von 0,1 s der bin�ren Null 
und solche mit einer Dauer von 0,2 s der bin�ren Eins. Die Zuordnung der einzelnen 
Sekundenmarken auf die �bertragene Zeitinformation zeigt das Kodierschema 


0.              Minutenbeginn (immer LOW)
1. - 14.        Reserviert, keine Bedeutung (neuedings: Verschl�selte Wetterdaten)
15.             Reserveantenne aktiv
16.             Umstellung von Sommer- auf Winterzeit, oder umgekehrt
17.             Sommerzeit aktiv
18.             Winterzeit aktiv
19.             Ank�ndigung Schaltsekunde
20.             Zeitbeginn (Immer High)
21. - 27.       Minute 1, 2, 4, 8, 10, 20, 40
28.             Pr�fbit Minute
29. - 34.       Stunde 1, 2, 4, 8, 10, 20
35.             Pr�fbit Stunde
36. - 41.       Tag 1, 2, 4, 8, 10, 20
42. - 44.       Wochentag 1, 2, 4
45. - 49.       Monat 1, 2, 4, 8, 10
50. - 57.       Jahr 1, 2, 4, 8, 10, 20, 40, 80
58.             Pr�fbit Datum
59.             fehlt zur Erkennung des Minutenanfangs

Die drei __Pr�fbits__ P1, P2 und P3 erg�nzen jeweils die vorhergehenden Informationsw�rter 
(7 Bits f�r die Minute, 6 Bits f�r die Stunden und 22 Bits f�r das Datum, einschlie�lich 
der Nummer des Wochentages) auf eine __gerade__ Anzahl von Einsen.

Die Zeitmarken Nr. 17 und 18 zeigen an, auf welches Zeitsystem sich die ausgesandte 
Zeitinformation bezieht. Bei Aussendung der MEZ wird die Sekundenmarke Nr. 18 auf 0,2 s
verl�ngert; die Sekundenmarke Nr. 17 hat eine Dauer von 0,1 s. Bei der Aussendung der 
MESZ ist es umgekehrt.

Vor einem �bergang von MEZ nach MESZ oder zur�ck wird au�erdem jeweils eine Stunde 
lang die Sekundenmarke Nr. 16 als verl�ngerte Marke (0,2 s) ausgesendet. Diese 
Verl�ngerung beginnt beim �bergang von MEZ auf MESZ (von MESZ nach MEZ) um 
01.00.16 Uhr MEZ (2.00.16 Uhr MESZ) und endet um 01.59.16 Uhr MEZ (02.59.16 Uhr MESZ).

Die Sekundenmarke Nr. 19 k�ndigt eine Schaltsekunde an. Sie wird dann ebenfalls 
eine Stunde lang vor Einf�hrung der Schaltsekunde als verl�ngerte Marke (0,2 s) 
ausgesendet. Schaltsekunden werden weltweit zum gleichen Zeitpunkt in die koordinierte 
Weltzeitskala UTC eingef�hrt, vorzugsweise am Ende der letzen Stunde des 31. Dezember 
oder des 30. Juni. Dies bedeutet, da� Schaltsekunden in der gesetzlichen Zeit der 
Bundesrepublik Deutschland eine Sekunde vor 1 Uhr MEZ am 1. Januar oder vor 
2 Uhr MESZ am 1. Juli eingeschoben werden. Bei einer Schaltsekunde am 1. Januar (1. Juli)
beginnt daher die Verl�ngerung der Sekundenmarke Nr. 19 um 00.00.19 Uhr MEZ (01.00.19 Uhr MESZ)
und endet um 00.59.19 Uhr MEZ (01.59.19 Uhr MESZ).

Beim Einf�gen einer Schaltsekunde hat die zugeh�rige Minute eine Dauer von 61 Sekunden,
und die der Marke 01.00.00 Uhr MEZ (02.00.00 Uhr MESZ) vorhergehende 59. Sekundenmarke 
wird mit einer Dauer von 0,1 s ausgesendet. Die zur eingef�gten 60. Sekunde geh�rige 
Marke wird weggelassen (keine Tr�gerabsenkung).

*/

//------------------------------------------------------------------------------

//Globale Variable
typedef struct {
  U8  zeitUebernehmen;
  U8  bBit[60];      //die empfangenen Bits
  U8  erfolgreichdecodiert;
  U8  stoerung;      //Unplausibler Empfang
  U8  zeitEmpfangen; //Schaltet auf Zeitanzeige statt Sekundenanzeige um


  U8  uhrHH;  //Die interne Uhr (wird von DCF-Uhr gestellt)
  U8  uhrMM;
  U8  uhrSS;
  U8  dcfSekunde; //0..59 - wird bei ausbleibendem Signal (59. Sekunde) auf 0 gesetzt

  U8  vorHH; //Die empfangene Zeit in der letzten Minute
  U8  vorMM;
  U8  vorJJ;
}Tglob;

Tglob volatile g;
U16		spalte[12];

//------------------------------------------------------------------------------

// Texte im Display
#define Z1 1
#define Z2 2
#define Z3 4
#define Z4 8
#define Z5 16
#define Z6 32
#define Z7 64
#define Z8 128
#define Z9 256
#define ZA 512

#define		TEXT_ES_IST			spalte[0]|=Z1; spalte[1]|=Z1; spalte[3]|=Z1; spalte[4]|=Z1; spalte[5]|=Z1
#define		TEXT_FUENF1			spalte[7]|=Z1; spalte[8]|=Z1; spalte[9]|=Z1; spalte[10]|=Z1

#define		TEXT_ZEHN1			spalte[0]|=Z2; spalte[1]|=Z2; spalte[2]|=Z2; spalte[3]|=Z2
#define		TEXT_ZWANZIG		spalte[4]|=Z2; spalte[5]|=Z2; spalte[6]|=Z2; spalte[7]|=Z2; spalte[8]|=Z2; spalte[9]|=Z2; spalte[10]|=Z2

#define		TEXT_DREI1			spalte[0]|=Z3; spalte[1]|=Z3; spalte[2]|=Z3; spalte[3]|=Z3
#define		TEXT_VIERTEL		spalte[4]|=Z3; spalte[5]|=Z3; spalte[6]|=Z3; spalte[7]|=Z3; spalte[8]|=Z3; spalte[9]|=Z3; spalte[10]|=Z3

#define		TEXT_NACH			  spalte[2]|=Z4; spalte[3]|=Z4; spalte[4]|=Z4; spalte[5]|=Z4
#define		TEXT_VOR	    	spalte[6]|=Z4; spalte[7]|=Z4; spalte[8]|=Z4

#define		TEXT_HALB			  spalte[0]|=Z5; spalte[1]|=Z5; spalte[2]|=Z5; spalte[3]|=Z5
#define		TEXT_ZWOELF		  spalte[5]|=Z5; spalte[6]|=Z5; spalte[7]|=Z5; spalte[8]|=Z5; spalte[9]|=Z5

#define		TEXT_ZWEI			  spalte[0]|=Z6; spalte[1]|=Z6; spalte[2]|=Z6; spalte[3]|=Z6
#define		TEXT_EIN			  spalte[2]|=Z6; spalte[3]|=Z6; spalte[4]|=Z6
#define		TEXT_EINS			  spalte[2]|=Z6; spalte[3]|=Z6; spalte[4]|=Z6; spalte[5]|=Z6; 
#define		TEXT_SIEBEN		  spalte[5]|=Z6; spalte[6]|=Z6; spalte[7]|=Z6; spalte[8]|=Z6; spalte[9]|=Z6; spalte[10]|=Z6

#define		TEXT_DREI			  spalte[1]|=Z7; spalte[2]|=Z7; spalte[3]|=Z7; spalte[4]|=Z7 
#define		TEXT_FUENF		  spalte[7]|=Z7; spalte[8]|=Z7; spalte[9]|=Z7; spalte[10]|=Z7

#define		TEXT_ELF			  spalte[0]|=Z8; spalte[1]|=Z8; spalte[2]|=Z8
#define		TEXT_NEUN 		  spalte[3]|=Z8; spalte[4]|=Z8; spalte[5]|=Z8; spalte[6]|=Z8
#define		TEXT_VIER		    spalte[7]|=Z8; spalte[8]|=Z8; spalte[9]|=Z8; spalte[10]|=Z8

#define		TEXT_ACHT			  spalte[1]|=Z9; spalte[2]|=Z9; spalte[3]|=Z9; spalte[4]|=Z9
#define		TEXT_ZEHN 		  spalte[5]|=Z9; spalte[6]|=Z9; spalte[7]|=Z9; spalte[8]|=Z9;

#define		TEXT_SECHS		  spalte[1]|=ZA; spalte[2]|=ZA; spalte[3]|=ZA; spalte[4]|=ZA; spalte[5]|=ZA
#define		TEXT_UHR  		  spalte[8]|=ZA; spalte[9]|=ZA; spalte[10]|=ZA


//  12345 12345 12345 12345 12345 12345 12345 12345 12345 12345 
//1   �    ���   ���     �  �����   ��  �����  ���   ���   ���  
//2  ��   �   � �   �   ��  �      �        � �   � �   � �   � 
//3   �       �     �  � �  ����  �        �  �   � �   � �   � 
//4   �      �    ��  �  �      � ����    �    ���   ���� �   � 
//5   �     �       � �����     � �   �  �    �   �     � �   � 
//6   �    �    �   �    �  �   � �   �  �    �   �     � �   � 
//7  ���  �����  ���     �   ���   ���   �     ���   ���   ���  
//


const U8 ziffern[10][5] = 				// Die 10 Ziffern in 5 Spalten und 7 Zeilen darstellen 
{//   1           2             3                    4                      5
	{Z2|Z3|Z4|Z5|Z6,  Z1|Z7,       Z1|Z7,                Z1|Z7,                Z2|Z3|Z4|Z5|Z6 },		// 0
	{0,               Z2|Z7,       Z1|Z2|Z3|Z4|Z5|Z6|Z7, Z7,                   0              },	  // 1
	{Z2|Z7,           Z1|Z6|Z7,    Z1|Z5|Z7,             Z1|Z4|Z7,             Z2|Z3|Z7       },		// 2
	{Z2|Z6,           Z1|Z7,       Z1|Z4|Z7,             Z1|Z4|Z7,             Z2|Z3|Z5|Z6    },		// 3
	{Z4|Z5,           Z3|Z5,       Z2|Z5,                Z1|Z2|Z3|Z4|Z5|Z6|Z7, Z5             },		// 4
	{Z1|Z2|Z3|Z6,     Z1|Z3|Z7,    Z1|Z3|Z7,             Z1|Z3|Z7,             Z1|Z4|Z5|Z6    },		// 5
	{Z3|Z4|Z5|Z6,     Z2|Z5|Z7,    Z1|Z4|Z7,             Z1|Z4|Z7,             Z5|Z6          },		// 6
  {Z1,              Z1|Z5|Z6|Z7, Z1|Z4,                Z1|Z3,                Z1|Z2          },		// 7
	{Z2|Z3|Z5|Z6,     Z1|Z4|Z7,    Z1|Z4|Z7,             Z1|Z4|Z7,             Z2|Z3|Z5|Z6    },		// 8
	{Z2|Z3,           Z1|Z4|Z7,    Z1|Z4|Z7,             Z1|Z4|Z7,             Z2|Z3|Z4|Z5|Z6 }		// 9
}; 


//------------------------------------------------------------------------------
void anzeigen(void){  // Zeit auf spaltes ausgeben (wird jede Sekunde aufgerufen)
//------------------------------------------------------------------------------
	U8	i,h,z,e;

  //Bildschirm l�schen
  for (i=0; i<12; spalte[i++]=0); 

	if(g.zeitEmpfangen){
		TEXT_ES_IST;
		if(     g.uhrMM <  5){TEXT_UHR;                    					}
		else if(g.uhrMM < 10){TEXT_FUENF1;  TEXT_NACH; 							}
		else if(g.uhrMM < 15){TEXT_ZEHN1;   TEXT_NACH; 							}
		else if(g.uhrMM < 20){TEXT_VIERTEL; TEXT_NACH; 							}
		else if(g.uhrMM < 25){TEXT_ZWANZIG; TEXT_NACH;              }
		else if(g.uhrMM < 30){TEXT_FUENF1;  TEXT_VOR;    TEXT_HALB;	}
		else if(g.uhrMM < 35){TEXT_HALB;  													}
		else if(g.uhrMM < 40){TEXT_FUENF1; 	TEXT_NACH; 	 TEXT_HALB;	}
		else if(g.uhrMM < 45){TEXT_ZWANZIG; TEXT_VOR; 	          	}
		else if(g.uhrMM < 50){TEXT_DREI1;   TEXT_VIERTEL;						}
		else if(g.uhrMM < 55){TEXT_ZEHN1;		TEXT_VOR;	  						}
		else if(g.uhrMM < 60){TEXT_FUENF1; 	TEXT_VOR;  							}

    h = g.uhrHH;
    if(g.uhrMM >=25) h++;
    
    switch(h%12){
      case  0: TEXT_ZWOELF; break;
      case  1: if (g.uhrMM < 5) {
                TEXT_EIN;
              }else{ 
                TEXT_EINS;
              } break;
      case  2: TEXT_ZWEI; break;
      case  3: TEXT_DREI; break;
      case  4: TEXT_VIER; break;
      case  5: TEXT_FUENF; break;
      case  6: TEXT_SECHS; break;
      case  7: TEXT_SIEBEN; break;
      case  8: TEXT_ACHT; break;
      case  9: TEXT_NEUN; break;
      case 10: TEXT_ZEHN; break;
      case 11: TEXT_ELF; break;
    }
 		;
    //Minuten mit 4 Pixeln am rechten Rand 
    switch(g.uhrMM % 5){
      case 4: spalte[11]|=BIT6; //absichtlich kein BREAK!
      case 3: spalte[11]|=BIT5; 
      case 2: spalte[11]|=BIT4; 
      case 1: spalte[11]|=BIT3; 
    }


	}else{ //Noch keine DCF-Zeit vorhanden. Zeige Sekunden.
		z = (g.dcfSekunde / 10);
		e = (g.dcfSekunde % 10);
    for (i=0; i<5; i++){
		  spalte[i] = ziffern[z][i];
		  spalte[i+6] = ziffern[e][i];
    }
	}
}


//------------------------------------------------------------------------------
ISR(TIMER1_COMPA_vect) { // spalte-Multiplexing (1882Hz)
//------------------------------------------------------------------------------
static U8	x;
static U16 scope=0; //12 Bit Speicher f�r Mini-Oszilloskop
static U8 us531=0;  //Z�hlt alle 531�s hoch
U16 y;

  //Low side: Eine einzelne 0 durchschieben (mit CLK) und jeweils mit STROBE aktivieren
	x++;
	if(x > 11){
		x=0;
		DO_DATA_L;
	}else{
		DO_DATA_H;
	}
  //Delays, um den  CD4094 nicht an seiner Grenze zu betreiben
  _delay_us(2); //Warte, bis Daten stabil anliegen 
	DO_CLK_H; //Einen weiter schieben
  _delay_us(2);
	DO_CLK_L;

  //Zeilentreiber l�schen
	PORTC &= ~0x0F;
	PORTD &= ~0xF0;
	PORTB &= ~0x03;

  //Spalte aktivieren (Low side)
	DO_STROBE_H; 
	DO_STROBE_L;

  //Spalte ausgeben (High side)
	y = spalte[x]; //10 Zeilentreiber, 12 Spalten
  //Solange noch keine Zeit empfangen: DCF-Signal in unteren beiden Zeilen anzeigen
  if (!g.zeitEmpfangen){  //Mini-Oszilloskop (simpler t-Y Schreiber ohne Trigger)
    us531++;
    if (us531 > 46){ //25ms sind rum
      us531=0;
      scope >>=1;//Pixel weiterschieben
    }  
    if (DI_DCF77_BIT){
      scope|=BIT11;  
    }else{ 
      scope&=~BIT11;
    }
    if (scope & (1<<x)){
      PORTB |=1;
    }else{
      PORTB |=2;
    }
  }else{
  	PORTB |= (y >> 8) & 0x03; //2Bit
  }

	PORTC |= y & 0x0F;        //4Bit
	PORTD |= y & 0xF0;        //4Bit
}


#if 0
//------------------------------------------------------------------------------
ISR(TIMER2_COMP_vect){ // 5ms Takt
//------------------------------------------------------------------------------
  PORTD|=BIT3; //volatile �bergabe an main()
}

#else //Das Ganze handoptimiert in Assembler, da Verz�gerungen das Multiplexing st�ren k�nnten.
void __attribute__ ((naked)) TIMER2_COMP_vect(void){ 
   asm("sbi	0x12, 3");   // High auf PD3 ausgeben
   asm("reti");
}
#endif




//------------------------------------------------------------------------------
//		MAIN
//------------------------------------------------------------------------------
int main(void)
{
static I16 iTic;        //ms seit letztem Absenkungsbeginn

static U8 bSteigend;    //TRUE: Tiefpass bewegt sich von 0 aufw�rts (Nahe Sekundenanfang)
static I16 iTiefpass;
static U8 startphase=1; 
static U8 toggle;
static U8 hh,mm,ss;
static I16 hs;
	
static U8 tag, wtag, monat, jahr;
static U8 neuesDatum=0;
static U8 keinEmpfang;    //Zeit ohne korrekten Empfang in Minuten 
static U8 zeitumstellung; //Wird bei gesetztem DCF-Bit 16 hochgez�hlt
static U8 sommerzeit;     //Wird bei gesetztem DCF-Bit 17 hochgez�hlt
static U8 winterzeit;     //Wird bei gesetztem DCF-Bit 18 hochgez�hlt
U8 pulsdauer;

U8 bChecksum;
U8 i;
U8 *ram;

  cli();
 	DDRC = BIT0|BIT1|BIT2|BIT3|BIT4;
	DDRD = BIT0|     BIT2|BIT3|BIT4|BIT5|BIT6|BIT7;
	DDRB = BIT0|BIT1|BIT2|BIT3|BIT4; 
	SFIOR &= (1<<PUD); //no Pullups
  
  PORTB=0;
  PORTC=0;
  PORTD=0;

   //Watchdog
  asm("wdr");
  WDTCR |= (1<<WDCE) | (1<<WDE);
  WDTCR=(1<<WDE) | (1<<WDP2) | (1<<WDP1)| (1<<WDP0); //Watchdog auf 2
  asm("wdr");


  DO_DCF_POWERSUPPLY;  //Saft auf DCF-Empf�nger
  DO_DCF_DISABLE;
  //Takt: 4.096MHz

  // Timer 0 unbenutzt
  
  // Timer 1  f�r spalte-Multiplexing 
	TCCR1A = 0;
  TCCR1B = (1<<WGM12) | (1<<CS11) | (1<<CS10); //Teiler 64 -> 64000Hz       
  OCR1A = 33; //Gibt 1882Hz Interruptfrequenz. Das erzeugt 156 Bilder/s
  //DCF77 sendet bei 77,5KHz. Die Multiplex-Frequenz sollte m�glichst kein ganzzahliger Teiler davon sein
  //  77500/1882=41,17 - krumm genug
	

	// Timer 2: 5ms DCF-77-Empfang Takt
	TCCR2	= (1<<WGM21)|(1<<CS22)|(1<<CS21) |(1<<CS20);			//CTC Mode,  Teiler 1024 -> 4KHz
  OCR2 = 19; //Gibt 200Hz Interruptfrequenz
  
	// Timer Interrupts
  TIMSK  = (1<<OCIE1A) | (1<<OCIE2); 


   //Globale Variablen mit Null initialisieren
  ram=(U8  *)&g;
  for (i=0; i< sizeof(Tglob); ram[i++]=0);

  //Warte, bis Spannungsversorgung des DCF-77-Empf�nger stabil
  asm("wdr");
  _delay_ms(1000);
  asm("wdr");
  DO_DCF_ENABLE; //Fallende Flanke auf PON startet den Empf�nger

  spalte[0]=Z1|ZA;
  spalte[11]=Z1|ZA;
 	sei();	// Interrupt ein - die Show beginnt	

	while(1){
    asm("wdr");

    if (!(PORTD & BIT3)) continue; //Sync auf 5ms Takt
    PORTD &= ~BIT3;

    
    iTic+=5;  //5ms sind rum
    if (iTic>3000){ //Kein Signal
      iTic=3000;
    }
    //Eingang abfragen und filtern
    if (DI_DCF77_BIT){ //Signalabsenkung liefert High f�r 100ms oder 200ms
      iTiefpass+=5;
      if (iTiefpass>200) iTiefpass=200;  //auf 200ms begrenzen
    }else{
      iTiefpass-=5;
      if (iTiefpass<0){
        iTiefpass=0;
        bSteigend=1;
      }
    }


    //Minutenanfang erkennen
    if (iTic > 1500){ //Minutensignal: mehr als 1s keine Absenkung
      g.dcfSekunde=59;
    }
    else
    //Signall�nge bestimmen und im Bitfeld eintragen
    if (160==iTic){ //160ms  Tiefpass ist entweder +100-60=40 oder +100+60=160
      pulsdauer=iTiefpass;
      if (iTiefpass > 90){      
        g.bBit[g.dcfSekunde]=1;
      }else{
        g.bBit[g.dcfSekunde]=0;
	    }
    
      if ((iTiefpass < 5) ||   ((iTiefpass > 60) && (iTiefpass <100))){ //Unplausible Signaldauer
        if (g.stoerung <4) g.stoerung++;  
      }else{
        if (g.stoerung >0) g.stoerung--;  
      }
    }
    //Sekundenanfang erkennen
    if ((60==iTiefpass) && bSteigend){ //60ms seit Pulsbeginn
      bSteigend=0;
      iTic=60;
      g.dcfSekunde++;
      if (g.dcfSekunde>59){  //Jetzt ist Minutenanfang
        g.dcfSekunde=0;
        if (0==startphase){ //beim 1. Minutenanfang nach Einschalten ist die Zeit noch nicht �bertragen
          g.zeitUebernehmen = 1;  
        }

        //Auswertung zum Minutenanfang
        if (g.zeitUebernehmen){
          if (g.bBit[16]){
            zeitumstellung++;
            }else{
            if (zeitumstellung) zeitumstellung--;
          }
          if (g.bBit[17]){
            if (sommerzeit < 60) sommerzeit++;
            }else{
            if (sommerzeit) sommerzeit--;
          }
          if (g.bBit[18]){
            if (winterzeit < 60) winterzeit++;
            }else{
            if (winterzeit) winterzeit--;
          }
          bChecksum=g.bBit[21]+g.bBit[22]+g.bBit[23]+g.bBit[24]+g.bBit[25]+g.bBit[26]+g.bBit[27]+g.bBit[28]; //Minute 
          if (0==(bChecksum % 2)){ //P1
            bChecksum=g.bBit[29]+g.bBit[30]+g.bBit[31]+g.bBit[32]+g.bBit[33]+g.bBit[34]+g.bBit[35];        //Stunde  
            if (0==(bChecksum % 2)){ //P2
              if (g.bBit[20]){ //Startbit; immer gesetzt
                bChecksum=0;
                for (i=36; i<59; i++){ //Checksumme �ber Datum 
                  bChecksum+=g.bBit[i];
                }
                if (0==(bChecksum % 2)){ //P3
                  neuesDatum=0;
                  keinEmpfang=0;
                  tag = g.bBit[36]+g.bBit[37]*2+g.bBit[38]*4+g.bBit[39]*8+g.bBit[40]*10+g.bBit[41]*20;
                  wtag = g.bBit[42]+g.bBit[43]*2+g.bBit[44]*4;
                  monat = g.bBit[45]+g.bBit[46]*2+g.bBit[47]*4+g.bBit[48]*8;
                  jahr = g.bBit[50]+g.bBit[51]*2+g.bBit[52]*4+g.bBit[53]*8+g.bBit[54]*10+g.bBit[55]*20+g.bBit[56]*40+g.bBit[57]*80;
                  if (g.zeitUebernehmen){
                    //�bernehme Zeit
                    g.zeitUebernehmen = 0;
                    hh = g.bBit[29]+g.bBit[30]*2+g.bBit[31]*4+g.bBit[32]*8+g.bBit[33]*10+g.bBit[34]*20;
                    mm = g.bBit[21]+g.bBit[22]*2+g.bBit[23]*4+g.bBit[24]*8+g.bBit[25]*10+g.bBit[26]*20+g.bBit[27]*40;
                    ss = 0;
			              //Ist diese Zeit genau eine Minute sp�ter als vor einer Minute? (zus�tzliche Plausibilit�tscheck)
                    g.vorMM++;
                    if (g.vorMM>59){
                      g.vorMM=0;
                      g.vorHH++;
                      if (g.vorHH >23) g.vorHH=0;
                    }
                    if ((g.vorHH == hh) 
                    && (g.vorMM == mm) 
                    && (g.vorJJ == jahr) //Beim Jahreswechsel muss die Uhr ja nicht um Mitternacht verdreht werden
                    && (jahr>10)){       //Wir haben 2011 - und mehr als 89 Jahre soll die Uhr gar nicht laufen
                      g.erfolgreichdecodiert=1;
                    }  
                    g.vorHH=hh;
                    g.vorMM=mm;
                    g.vorJJ=jahr; 
                  }
                }//P3
              }//Bit20
            }//P2
          }//P1
        }//g.zeitUebernehmen
        if (startphase) startphase--;
        for (i=0; i<60; i++){
          g.bBit[i]=0;
        }
      }//(g.dcfSekunde>59)
    
      //Interne Uhr feintunen
      //Hundertstel Sekunden g.hs sollte auf 6 stehen , wenn die Uhr richtig l�uft (60ms seit steigender Flanke)
      //Nur machen, wenn Empfang OK
      if ((keinEmpfang < 2) && (0==g.stoerung)){
        if ((hs > 6) && (hs < 56)) {
          hs --; //Uhr etwas zur�ckdrehen
        }else{
          if (hs != 6){
            hs++; //Uhr etwas vor drehen. �berlauf wird weiter unten automatisch behandelt.
          }  
        }
      }
    }//Sekundenanfang (60ms)

    //Intere Uhr weiterdrehen
    toggle = !toggle;
    if (toggle){ //10ms sind rum
      hs++; //Hundertstel Sekunden
      if (hs>99){ //1s ist rum
        hs-=100; //Nicht auf 0 setzen, um �berlauf bei Uhr vordrehen (Feintuning) zu ber�cksichtigen
        g.uhrSS++;
        anzeigen();
        if (g.uhrSS > 59){
          g.uhrSS=0;
          g.uhrMM++;
          if (keinEmpfang < 100){ //Wird bei Empfang mit korreten Pr�fsummen auf 0 gesetzt	
            keinEmpfang++;
          }	
          if (g.uhrMM > 59){
            g.uhrMM=0;
            g.uhrHH++;
            if (g.uhrHH > 23){
              g.uhrHH=0;
              neuesDatum=1; //Datum wird ja nicht angezeigt. Aber wenn ich das mal einbauen will, habe ich hiermit den Tagesbeginn.
            } 
            //Zeitumstellung?
            if ((zeitumstellung > 45) && (g.uhrHH >=2) && (g.uhrHH <=3)){ //"zeitumstellung" wurde in der Stunde vor der Umstellung jede Minute hochgez�hlt
              if (sommerzeit > winterzeit){ //MESZ->MEZ
                g.uhrHH--;
              }else{ //MEZ->MESZ
                g.uhrHH++;
              }
            }
          }//g.uhrMM>59
        }//g.uhrSS>59
        if (g.erfolgreichdecodiert){ //Zeit �bernehmen (wenn vorhanden)
          g.erfolgreichdecodiert=0;
          g.zeitEmpfangen=1;
          g.uhrHH=hh;
          g.uhrMM=mm;
          g.uhrSS=0;
		    }

      }//hs>99
    }//Toggle
	}//while 1
}
//EOF

